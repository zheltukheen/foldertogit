#!/bin/bash

# Установка для обработки пробелов в именах файлов и папок
IFS=$'\n'

# Переменные для хранения параметров скрипта
SOURCE_DIR="."
TARGET_DIR="git_history"
AUTHOR_NAME="Developer"
AUTHOR_EMAIL="dev@example.com"
VERSION_PATTERN="[0-9]+"
DRY_RUN=false
VERBOSE=false
PATTERN="*"

# Функция использования скрипта
usage() {
    echo "Использование: $0 [опции]"
    echo "Опции:"
    echo "  --source DIR       Исходная директория (по умолчанию: текущая директория)"
    echo "  --target DIR       Целевая директория для Git-репозитория (по умолчанию: git_history)"
    echo "  --pattern PATTERN  Шаблон для поиска директорий с версиями (по умолчанию: *)"
    echo "  --version-pattern PATTERN  Регулярное выражение для извлечения версии из имени директории (по умолчанию: [0-9]+)"
    echo "  --author NAME      Имя автора для коммитов (по умолчанию: Developer)"
    echo "  --email EMAIL      Email автора для коммитов (по умолчанию: dev@example.com)"
    echo "  --dry-run          Запуск без внесения изменений"
    echo "  --verbose          Подробный вывод"
    echo "  --help             Показать эту справку"
    exit 1
}

# Обработка параметров командной строки
while [[ $# -gt 0 ]]; do
    case $1 in
        --source)
            SOURCE_DIR="$2"
            shift 2
            ;;
        --target)
            TARGET_DIR="$2"
            shift 2
            ;;
        --pattern)
            PATTERN="$2"
            shift 2
            ;;
        --version-pattern)
            VERSION_PATTERN="$2"
            shift 2
            ;;
        --author)
            AUTHOR_NAME="$2"
            shift 2
            ;;
        --email)
            AUTHOR_EMAIL="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --verbose)
            VERBOSE=true
            shift
            ;;
        --help)
            usage
            ;;
        *)
            echo "Неизвестный параметр: $1"
            usage
            ;;
    esac
done

# Функция для получения времени создания самого старого файла в директории
get_oldest_file_time() {
    local dir="$1"
    local oldest_time=""
    local oldest_file=""
    
    # Ищем важные файлы первыми (config.py, main.py и т.д.)
    for priority_file in $(find "$dir" -type f -name "main.py" -o -name "config.py" 2>/dev/null | head -10); do
        if [[ -z "$oldest_file" ]]; then
            oldest_file="$priority_file"
            oldest_time=$(stat -f "%m" "$priority_file")
        else
            file_time=$(stat -f "%m" "$priority_file")
            if [[ "$file_time" -lt "$oldest_time" ]]; then
                oldest_time="$file_time"
                oldest_file="$priority_file"
            fi
        fi
    done
    
    # Если не найдены приоритетные файлы, ищем остальные
    if [[ -z "$oldest_file" ]]; then
        for file in $(find "$dir" -type f 2>/dev/null | head -30); do
            if [[ -z "$oldest_file" ]]; then
                oldest_file="$file"
                oldest_time=$(stat -f "%m" "$file")
            else
                file_time=$(stat -f "%m" "$file")
                if [[ "$file_time" -lt "$oldest_time" ]]; then
                    oldest_time="$file_time"
                    oldest_file="$file"
                fi
            fi
        done
    fi
    
    if [[ -n "$oldest_file" ]]; then
        # Вернём человекочитаемое время для логов
        echo "$oldest_file, время (версия: $(date -r "$oldest_time" '+%Y-%m-%d %H:%M:%S'))"
    else
        echo "$dir, время (версия: неизвестная дата)"
    fi
}

# Создаем целевую директорию, если она не существует
if [[ ! -d "$TARGET_DIR" && "$DRY_RUN" == "false" ]]; then
    mkdir -p "$TARGET_DIR"
    echo "[INFO] Создана директория $TARGET_DIR"
fi

# Инициализируем Git-репозиторий, если это не сухой запуск
if [[ "$DRY_RUN" == "false" ]]; then
    cd "$TARGET_DIR" || exit 1
    git init
    echo "[INFO] Инициализирован Git-репозиторий в $(pwd)"
    cd - > /dev/null || exit 1
fi

# Создаем временный файл для хранения информации о директориях и их версиях
TEMP_FOLDER_LIST=$(mktemp)

# Находим все директории, соответствующие шаблону
for dir in $(find "$SOURCE_DIR" -maxdepth 1 -type d -name "$PATTERN" | sort); do
    # Извлекаем версию из имени директории
    version=$(echo "$dir" | grep -oE "$VERSION_PATTERN" | head -1)
    
    if [[ -n "$version" ]]; then
        # Получаем время создания самого старого файла
        dir_info=$(get_oldest_file_time "$dir")
        creation_info="${dir_info##*, время \(версия: }"
        creation_info="${creation_info%)}"
        
        # Сохраняем информацию о папке в формате "creation_time:path:version"
        if [[ "$VERBOSE" == "true" ]]; then
            echo "[DEBUG] Найдена папка $(basename "$dir") (версия: $version, создана: $creation_info)"
        fi
        
        timestamp=$(date -j -f "%Y-%m-%d %H:%M:%S" "$creation_info" "+%s" 2>/dev/null)
        if [[ $? -ne 0 ]]; then
            # Если формат даты не распознан, используем текущую дату
            timestamp=$(date "+%s")
        fi
        
        echo "$timestamp:$dir:$version" >> "$TEMP_FOLDER_LIST"
    fi
done

# Подсчитываем количество найденных директорий
folder_count=$(wc -l < "$TEMP_FOLDER_LIST")
echo "[INFO] Найдено $folder_count директорий с версиями проекта"

if [[ "$DRY_RUN" == "true" ]]; then
    echo "[INFO] Режим сухого запуска (dry run) - репозиторий не будет создан"
fi

# Сортируем список директорий по времени создания (хронологически)
echo "[INFO] Список найденных директорий и их версий (в хронологическом порядке):"
sort -n "$TEMP_FOLDER_LIST" > "${TEMP_FOLDER_LIST}.sorted"
mv "${TEMP_FOLDER_LIST}.sorted" "$TEMP_FOLDER_LIST"

# Обрабатываем директории в отсортированном порядке
while IFS=: read -r timestamp dir version; do
    # Получаем информацию о времени создания для логов
    file_info=$(get_oldest_file_time "$dir")
    echo "[INFO]    $file_info"
done < "$TEMP_FOLDER_LIST"

# Сводка по периодам разработки
echo "[INFO]    $(date -r "$timestamp" '+%Y-%m-%d %H') (версия: $version, создана: $(date -r "$timestamp" '+%Y-%m-%d %H:%M:%S'))"

# Если это не сухой запуск, копируем файлы и создаем коммиты
if [[ "$DRY_RUN" == "false" ]]; then
    echo "[INFO] Создание коммитов в хронологическом порядке..."
    
    while IFS=: read -r timestamp dir version; do
        echo "[INFO] Обработка $(basename "$dir") (версия: $version)"
        
        # Очищаем целевую директорию перед копированием
        rm -rf "$TARGET_DIR"/*
        
        # Копируем файлы из версии проекта
        cp -r "$dir"/* "$TARGET_DIR"/
        
        cd "$TARGET_DIR" || exit 1
        
        # Добавляем все файлы в Git
        git add -A
        
        # Форматируем дату для Git (ISO 8601)
        commit_date=$(date -r "$timestamp" '+%Y-%m-%dT%H:%M:%S')
        
        # Создаем коммит с историческими датами
        echo "[INFO] Установка даты коммита на $commit_date"
        GIT_AUTHOR_DATE="$commit_date" GIT_COMMITTER_DATE="$commit_date" \
        git commit -m "Версия $version ($(basename "$dir"))" --author="$AUTHOR_NAME <$AUTHOR_EMAIL>"
        
        echo "[INFO] Создан коммит для версии $version с датой $commit_date"
        
        cd - > /dev/null || exit 1
    done < "$TEMP_FOLDER_LIST"
    
    echo "[INFO] Все коммиты успешно созданы в $TARGET_DIR"
else
    echo "[INFO] Окончание сухого запуска"
fi

# Удаляем временный файл
rm -f "$TEMP_FOLDER_LIST" 